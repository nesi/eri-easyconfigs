# TODO for freebayes

- [ ] Update Debian
- [ ] Update Conda
- [ ] Fix CI builds
- [ ] Introduce metrics such as from rtg-tools https://hpc.nih.gov/apps/rtg-tools.html
