#define HTS_VERSION_TEXT "freebayes htslib"
#define HTSCODECS_VERSION_TEXT ""
