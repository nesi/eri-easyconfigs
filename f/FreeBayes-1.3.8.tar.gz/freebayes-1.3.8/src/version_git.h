#ifndef VERSION_GIT_H
#define VERSION_GIT_H
#define VERSION_GIT "v1.3.8"
#endif /* VERSION_GIT_H */
